import {getOrSetModelFromCache} from '../src/cache'
import initModel from '../src/instances'


function getModelFromConnection(connection, tableName, options) {

  const model= getOrSetModelFromCache(connection, tableName, options, () => {
    return initModel(connection.config, tableName, options)
  }) 
  return model
}


export default getModelFromConnection
