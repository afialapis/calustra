# GLIBC errors with node_sqlite3

Use this versions to solve:

```
$ node --version
v16.14.0
$ npm --version
8.3.1
```

