import {initCache} from 'cacheiro'

const cache = initCache('raw')

export default cache