import test_table_names from './table_names.mjs'

test_table_names()