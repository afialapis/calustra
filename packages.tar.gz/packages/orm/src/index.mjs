import getConnection from './getConnectionWrap.mjs'

export {getConnection}
